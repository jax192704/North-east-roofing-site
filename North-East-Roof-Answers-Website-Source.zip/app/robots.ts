import type { MetadataRoute } from "next";
import { site } from "@/lib/roofing-data";
export default function robots():MetadataRoute.Robots{return{rules:{userAgent:"*",allow:"/"},sitemap:`${site.url}/sitemap.xml`}}
